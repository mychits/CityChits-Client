import React from 'react'

const PayoutReport = () => {
  return (
    <div>PayoutReport</div>
  )
}

export default PayoutReport