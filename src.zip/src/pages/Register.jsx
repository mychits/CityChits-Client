import { useState } from "react";
import { AiOutlineGold } from "react-icons/ai";
import { useNavigate, Link } from "react-router-dom";
import api from "../instance/TokenInstance";

const Register = () => {

};

export default Register;
