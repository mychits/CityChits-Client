const hotkeys = [
  {
    key:"$1",path: "/reports/group-report",
    title:"Group Report"
  },
  {
    key:"$2",path: "/reports/daybook",
    title:"DayBook"
  },
  {
    key:"$3",path: "/reports/receipt",
    title:"Receipt"
  },
  {
    key:"$4",path: "/reports/user-report",
    title:"User Report"
  },
  {
    key:"$5",path: "/reports/all-customer-report",
    title:"All Customer Report"

  },
  {
    key:"$6",path: "/marketing/what-add",
    title:"Whatsapp Advertisement"
  },
];
export default hotkeys