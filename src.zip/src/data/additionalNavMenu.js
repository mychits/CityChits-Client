const additionalNavMenu = [
    {
        title:"settings",
        link:"",
        icon:""
    },
    {
        title:"Help & Support",
        link:"",
        icon:""
    },
    {
        title:"Log Out",
        link:"",
        icon:""
    }
]