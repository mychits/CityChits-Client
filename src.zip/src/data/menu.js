export const NavbarMenu = [
  {
    id: 1,
    title: "About",
    link: "/about",
  },
  {
    id: 2,
    title: "ReadMe",
    link: "/readme",
  },
  {
    id: 3,
    title: "Privacy",
    link: "/privacy",
  },
  {
    id: 4,
    title: "Guide",
    link: "/guide",
  },
];
